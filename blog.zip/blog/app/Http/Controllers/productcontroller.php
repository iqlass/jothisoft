<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Maatwebsite\Excel\Facades\Excel;
use App\productmodel;
use redirect;
use Session;
use Exception;
class productcontroller extends Controller
{
    public function importfile(request $request){
		try{
			$path = $request->file('csv_file')->getRealPath();
			 $data = array_map('str_getcsv', file($path));
			  foreach($data as $i=>$data){
				if($i != 0){
					
						$value['ProductId'] = $data[0];
						$value['Condition'] = $data[1];
						$value['SKU'] = $data[2];
						$value['Title'] = $data[3];
						$value['Qty'] = $data[4];
						$value['Price'] = $data[5];
						
						$check_value = $this->check_value($data[0],$data[1],$data[2]);
						if($check_value == 0 ){
							productmodel::create($value);
							$data = array('status'=>'status','msg'=>'Insert Successfully');
						}else{
							$data = array('status'=>'status','msg'=>'This Data Already Inserted');
							  
							
						}
					
				}
			  }
		}
		catch(Exception $e){
			$data = array('status'=>'error','msg'=>$e->getMessage());
			Log::error($data);
		}
		finally{
			Session::put('msg',$data);
			return redirect('/');
		}
			

	}
	public function check_value($ProductId,$Condition,$SKU){
		$cat_count = productmodel::where('ProductId',$ProductId)
			->orWhere('Condition',$Condition)
			->orWhere('SKU',$SKU)->count();
		
		return $cat_count;
	}
	public function index(){
		$data = productmodel::all();
		return view('welcome',compact('data'));
	}
}
