<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class productmodel extends Model
{
    protected $table = 'tbl_product';
    protected $primaryKey = 'pro_id';
    protected $fillable = [
        'ProductId', 'Condition', 'SKU','Title','Qty','Price',
    ];
}
