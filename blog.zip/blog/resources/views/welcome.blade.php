<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
			<div class="panel panel-default">
				<div class="panel-heading">Import File </div>
				<div class="panel-body">
					<form enctype="multipart/form-data"  method="post" action="{{url('file_upload')}}">
						<div class="form-group" >
						@csrf
						<label for="email">File Upload:</label>
						<input type="file" name="csv_file"   class="form-control"/>

						</div>

						<button type="submit" class="btn btn-default">Submit</button>
					</form>
				</div>
			</div>
			<table class="table table-striped">
				<thead>
				<tr>
					<th>ProductId</th>
					<th>Condition</th>
					<th>SKU</th>
					<th>Title</th>
					<th>Qty</th>
					<th>Price</th>
				</tr>
				</thead>
				<tbody>
				<tr>
				@foreach($data as $value)
					<td>{{$value->ProductId}}</td>
					<td>{{$value->Condition}}</td>
					<td>{{$value->SKU}}</td>
					<td>{{$value->Title}}</td>
					<td>{{$value->Qty}}</td>
					<td>{{$value->Price}}</td>
				@endforeach
				</tr>
				</tbody>
			</table>
    </body>
</html>
